"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
# In My_non_profit_management_10/config/urls.py
from django.contrib import admin
from django.urls import path, include  # Make sure 'include' is imported!

urlpatterns = [
    path('admin/', admin.site.urls),
    # This line tells Django that any URL starting with 'projects/'
    # should be handled by the rules in 'projects.urls' (the file you just created).
    path('projects/', include('projects.urls')),
]
