# Simple Non-Profit Project Manager(Web Application)
## 1. Project Overview

This web application, "Simple Non-Profit Project Manager," is designed to provide small non-profit organizations with an intuitive and accessible tool for managing their projects, tasks, volunteers, and basic resources. It aims to address the common challenge where existing project management software is often too complex or costly for the needs of smaller NPOs.

This project is being developed as part of the **Project: Software Engineering (DLMCSPSE01)** course at **IU International University of Applied Sciences**.

* **Author:** Vishal Roy
* **Matriculation Number:** UPS10604539
* **Tutor:** Holger Klus

## 2. Core Features

The application aims to include the following core functionalities:

* **Project Management:** Create, view, update, and delete projects.
* **Task Management:** Define tasks within projects, assign them to users (staff/volunteers), and track their status.
* **Volunteer Coordination:** Basic tools to manage volunteer information and assign them to tasks or project roles.
* **Donation & Resource Tracking:** Simple logging of monetary and in-kind donations, and tracking of other project resources.
* **User Authentication:** Secure login for registered users.

## 3. Technology Stack

* **Backend:** Python 3.12, Django Web Framework 
* **Database:** SQLite 3 (for development)
* **Frontend:** HTML, CSS (JavaScript for minor enhancements planned)
* **Version Control:** Git & GitHub
* **Development Environment:** Python Virtual Environment (`venv`)
* **(For Finalization Phase):** Docker (using Docker Compose)

## 4. Setup and Local Installation

To set up and run this project locally, please follow these steps:

1.  **Prerequisites:**
    * Git
    * Python 3.12 (or the version specified in the project)
    * pip (Python package installer)

2.  **Clone the repository:**
    ```bash
    git clone [https://github.com/roy612vishal/Vishal-Roy-My_non_profit_management_10.git](https://github.com/roy612vishal/Vishal-Roy-My_non_profit_management_10.git)
    cd Vishal-Roy-My_non_profit_management_10
    ```

3.  **Create and activate a virtual environment:**
    ```bash
    # For Windows
    python -m venv venv
    venv\Scripts\activate

    # For macOS/Linux
    python3 -m venv venv
    source venv/bin/activate
    ```

4.  **Install dependencies:**
    ```bash
    pip install -r requirements.txt
    ```
    *(Note: Make sure you have created a `requirements.txt` file by running `pip freeze > requirements.txt` in your activated venv after installing Django).*

5.  **Apply database migrations:**
    ```bash
    python manage.py migrate
    ```

6.  **Create a superuser (admin account):**
    ```bash
    python manage.py createsuperuser
    ```
    *(Follow the prompts to set a username, email, and password).*

7.  **Run the development server:**
    ```bash
    python manage.py runserver
    ```

8.  Access the application in your browser:
    * Main site (project list): `http://127.0.0.1:8000/projects/`
    * Admin panel: `http://127.0.0.1:8000/admin/`

## 5. Current Status

"Currently in the Development Phase. Core functionalities for Project listing, detail views, and creation are implemented. Automated tests for basic views are in place."

## 6. Course Context

This project fulfills the requirements for the **Project: Software Engineering (DLMCSPSE01)** portfolio at IU International University of Applied Sciences. All relevant documentation as per the course guidelines (Conception Phase, Development Phase/Reflection, Finalization Phase deliverables) will be included in the respective portfolio submissions.

Thank You