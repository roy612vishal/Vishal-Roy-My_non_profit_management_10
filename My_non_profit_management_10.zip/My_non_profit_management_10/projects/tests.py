# File: My_non_profit_management_10/projects/tests.py

from django.test import TestCase  # IMPORTANT: Import TestCase
from django.urls import reverse   # Helper to get URLs by their 'name'
from .models import Project      # Import your Project model if you test things related to it

# 1. Your test class MUST inherit from django.test.TestCase
class ProjectViewTests(TestCase): # You can name the class what you like, but (TestCase) is key

    # 2. OPTIONAL: A setUp method to create test data (runs before each test method)
    def setUp(self):
        Project.objects.create(name="My First Test Project", description="A description for testing.")
        Project.objects.create(name="My Second Test Project", description="Another description.")

    # 3. Your test methods MUST start with 'test_'
    def test_project_list_page_status_code_is_ok(self):
        # Get the URL for the 'project_list' page (from projects/urls.py name='project_list')
        url = reverse('project_list')
        response = self.client.get(url) # Simulate a browser visiting the page
        self.assertEqual(response.status_code, 200) # Check if the page loaded successfully

    def test_project_list_page_uses_correct_template(self):
        url = reverse('project_list')
        response = self.client.get(url)
        self.assertTemplateUsed(response, 'projects/project_list.html') # Check correct template

    def test_project_list_page_displays_project_names(self):
        url = reverse('project_list')
        response = self.client.get(url)
        self.assertContains(response, "My First Test Project") # Check if project name is on the page
        self.assertContains(response, "My Second Test Project")

    # You can add more test methods here, each starting with 'test_'
    # For example, to test your project_detail_view if you've created it:
    # def test_project_detail_page_status_code_is_ok(self):
    #     project = Project.objects.get(name="My First Test Project")
    #     url = reverse('project_detail', args=[project.id]) # Assuming name='project_detail' and it takes project.id
    #     response = self.client.get(url)
    #     self.assertEqual(response.status_code, 200)
    #     self.assertContains(response, "My First Test Project")
