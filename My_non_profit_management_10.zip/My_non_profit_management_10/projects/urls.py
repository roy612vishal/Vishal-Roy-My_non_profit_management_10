# In My_non_profit_management_10/projects/urls.py
from django.urls import path
from . import views # This line is correct here

urlpatterns = [
    path('', views.project_list_view, name='project_list'),
    path('<int:project_id>/', views.project_detail_view, name='project_detail'),
    path('create/', views.project_create_view, name='project_create'),
]