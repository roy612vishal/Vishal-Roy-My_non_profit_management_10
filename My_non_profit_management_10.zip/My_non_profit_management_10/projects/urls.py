# In My_non_profit_management_10/projects/urls.py
# In My_non_profit_management_10/projects/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.project_list_view, name='project_list'),
    # ADD THIS NEW LINE for project details:
    path('<int:project_id>/', views.project_detail_view, name='project_detail'),
    # '<int:project_id>/' captures a number from the URL and calls it project_id
]