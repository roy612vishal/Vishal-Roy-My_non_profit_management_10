# In My_non_profit_management_10/projects/models.py
from django.db import models
from django.conf import settings # Import settings if you use AUTH_USER_MODEL

class Project(models.Model):  # <<< Project is defined FIRST
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True, null=True)
    start_date = models.DateField(null=True, blank=True)

    def __str__(self):
        return self.name

class Task(models.Model):     # <<< Task is defined AFTER Project
    project = models.ForeignKey(
        Project,                  # Now Python knows what 'Project' is
        on_delete=models.CASCADE,
        related_name='tasks'
    )
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    # ... rest of your Task model fields ...

    def __str__(self):
        return self.name