# In My_non_profit_management_10/projects/views.py
from django.shortcuts import render, get_object_or_404 # Make sure get_object_or_404 is imported if you added the detail view
from .models import Project # Import your Project model

# Function to display the list of all projects
def project_list_view(request):
    all_projects = Project.objects.all()
    context = {
        'projects_to_display': all_projects,
    }
    # Ensure this line uses the correct template path
    return render(request, 'projects/project_list.html', context)

# Function to display the details of ONE project
# Make sure this function definition is also correct if you added it
def project_detail_view(request, project_id):
    project = get_object_or_404(Project, pk=project_id)
    context = {
        'project_to_display': project,
    }
    # Ensure this line uses the correct template path
    return render(request, 'projects/project_detail.html', context)

# If you added the project_create_view, make sure it's here too
# def project_create_view(request): ...