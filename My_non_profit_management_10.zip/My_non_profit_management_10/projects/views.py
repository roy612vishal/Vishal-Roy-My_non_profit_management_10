# In My_non_profit_management_10/projects/views.py
from django.shortcuts import render, get_object_or_404, redirect
from .models import Project, Task # Assuming Task model is also in models.py
from .forms import ProjectCreateForm # Assuming ProjectCreateForm is in projects/forms.py

# Function to display the list of all projects
def project_list_view(request):
    all_projects = Project.objects.all()
    context = {
        'projects_to_display': all_projects,
    }
    return render(request, 'projects/project_list.html', context)

# Function to display the details of ONE project
def project_detail_view(request, project_id):
    project = get_object_or_404(Project, pk=project_id)
    # Assuming you want to display tasks related to this project:
    tasks_for_this_project = project.tasks.all() # Or Task.objects.filter(project=project)
    context = {
        'project_to_display': project,
        'tasks_to_display': tasks_for_this_project,
    }
    return render(request, 'projects/project_detail.html', context)

# Function to handle creating a new project
def project_create_view(request):
    if request.method == 'POST':
        form = ProjectCreateForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('project_list') # Redirects to the project list page
    else:
        form = ProjectCreateForm()
    context = {
        'form': form,
    }
    return render(request, 'projects/project_create_page.html', context)