# File: My_non_profit_management_10/projects/forms.py

from django import forms
from .models import Project  # Import  Project blueprint

class ProjectCreateForm(forms.ModelForm):
    class Meta:
        model = Project  # Telling Django this form is for creating/editing Projects
        # List the fields from Project model that you want on the form
        fields = ['name', 'description', 'start_date']
        