# File: My_non_profit_management_10/projects/forms.py

from django import forms
from .models import Project  # Import your Project blueprint

class ProjectCreateForm(forms.ModelForm):
    class Meta:
        model = Project  # Tell Django this form is for creating/editing Projects
        # List the fields from your Project model that you want on the form
        fields = ['name', 'description', 'start_date']
        # You can add more fields here if your Project model has them (e.g., 'end_date', 'project_lead')