# In My_non_profit_management_10/projects/admin.py
from django.contrib import admin
from .models import Project

admin.site.register(Project)
