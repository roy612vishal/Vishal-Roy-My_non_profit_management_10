#!/usr/bin/env python
"""Django's command-line utility for administrative tasks."""
import os
import sys

def main():
    """Run administrative tasks."""  # Indented
    # Ensure 'config.settings' matches your project's settings file location
    # Based on our setup, our settings are in 'config/settings.py'
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')  # Indented
    try:  # Indented
        from django.core.management import execute_from_command_line
    except ImportError as exc:  # Indented
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)  # Indented

if __name__ == '__main__':  # Corrected condition and at the top level (no indent)
    main()  # Indented under the 'if'